package com.example.donemate.ui.screens.change_email

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.donemate.data.repository.remote.AccountRepository
import com.example.donemate.data.repository.remote.AuthResult
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ChangeEmailForm(
    val email: String = "",
    val password: String = "",
    val errorMessage: String? = null,
)

data class ChangeEmailUiState(
    val changeEmailForm: ChangeEmailForm = ChangeEmailForm(),
    val isUserVerified: Boolean? = false
)

@HiltViewModel
class ChangeEmailViewModel @Inject constructor(
    private val accountRepository: AccountRepository
) : ViewModel() {
    val isUserVerified = accountRepository.isUserVerified
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = null
        )

    private val _changeEmailForm = MutableStateFlow(ChangeEmailForm())

    val uiState: StateFlow<ChangeEmailUiState> =
        combine(_changeEmailForm, isUserVerified) { changeEmailForm, isUserVerified ->
            ChangeEmailUiState(
                changeEmailForm = changeEmailForm,
                isUserVerified = isUserVerified
            )
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = ChangeEmailUiState()
        )


    fun updateEmail(email: String) {
        _changeEmailForm.value = _changeEmailForm.value.copy(email = email)
    }

    fun changeEmail() {
        viewModelScope.launch {
            val result = accountRepository.changeEmail(email = _changeEmailForm.value.email)
            when (result) {
                is AuthResult.Success -> {

                }

                is AuthResult.Error -> {
                    _changeEmailForm.value = _changeEmailForm.value.copy(errorMessage = result.message)

                }
            }

        }
    }


    fun errorMessageShown() {
        _changeEmailForm.value = _changeEmailForm.value.copy(
            errorMessage = null
        )
    }
}